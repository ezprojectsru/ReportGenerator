﻿
namespace ReportGenerator.DataBase.Models
{
    /// <summary>
    /// Класс модели Группы
    /// </summary>
    public class Group
    {
        public int id { get; set; }
        public string name { get; set; }
        public string description { get; set; }
    }
}
