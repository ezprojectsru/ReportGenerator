﻿

namespace ReportGenerator.DataBase.Models
{
    public class Sector
    {
        /// <summary>
        /// Класс модели Сектора
        /// </summary>
        public int id { get; set; }
        public string name { get; set; }
        public string description { get; set; }
    }
}
